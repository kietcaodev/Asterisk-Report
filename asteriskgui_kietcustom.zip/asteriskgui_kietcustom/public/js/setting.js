function monitor() {
    return "/var/spool/asterisk/monitor/";
}
